package com.tripnetra.extranet.rest;

public interface callback_interface {
    void getResponse(String response);
}
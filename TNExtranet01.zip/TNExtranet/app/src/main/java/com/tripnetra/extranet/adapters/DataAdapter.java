package com.tripnetra.extranet.adapters;

public class DataAdapter {

    private String fname,bookstatus,cintype,mobile,rtype,rimage,cindate,coutdate,pnrno,hname,hid,rtypeid,price,neftimps,refid;

    public String getFname(){return fname;}
    public void setFname(String string){this.fname = string;}

    public String getBookStat(){return bookstatus;}
    public void setBookStat(String string){this.bookstatus = string;}

    public String getCinType(){return cintype;}
    public void setCinType(String string){this.cintype = string;}

    public String getMobile(){return mobile;}
    public void setMobile(String string){this.mobile = string;}

    public String getRType(){return rtype;}
    public void setRType(String string){this.rtype = string;}

    public String getRImage(){return rimage;}
    public void setRImage(String string){this.rimage = string;}

    public String getCinDate(){return cindate;}
    public void setCinDate(String string){this.cindate = string;}

    public String getCoutDate(){return coutdate;}
    public void setCoutDate(String string) {this.coutdate = string;}

    public String getPnrNo() {return pnrno;}
    public void setPnrNo(String string) {this.pnrno = string;}

    public String getHName() {return hname;}
    public void setHName(String string) {this.hname = string;}

    public String getHotelId() {return hid;}
    public void setHotelId(String string) {this.hid = string;}

    public String getRTypeId() {return rtypeid;}
    public void setRTypeId(String string){this.rtypeid = string;}

    public String getPrice(){return price;}
    public void setPrice(String string){this.price = string;}

    public String getNeftImps(){return neftimps;}
    public void setNeftImps(String string){this.neftimps = string;}

    public String getRefId(){return refid;}
    public void setRefId(String string){this.refid = string;}

}